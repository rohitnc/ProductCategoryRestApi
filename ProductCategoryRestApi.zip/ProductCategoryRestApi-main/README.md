# ProductCategoryRestApi
In this project,I developed API using Spring Boot and Hibernate.Entities involved were Product and Category.Relationship between product and category is one to many . I performed CRUD operations on these entities.Also while retrieving information of product,I also displayed information of it's category.Kindly refer to attached txt file for running the project.
